# Ejercicio de AdaTasks para el pair programming del módulo 3

Aquí tenemos una aplicación web para llevar nuestra lista de tareas pendientes.
